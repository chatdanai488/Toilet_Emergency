.. _contribute:

.. include:: ../../CONTRIBUTING.rst
